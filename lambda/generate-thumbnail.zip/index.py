import json
import boto3
import urllib.parse

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

# Change this to your actual table name
TABLE_NAME = 'FileMetadata'

def handler(event, context):
    print("Received event:", json.dumps(event))

    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        
        try:
            # Get file metadata
            response = s3.head_object(Bucket=bucket, Key=key)
            file_size = response['ContentLength']
            content_type = response['ContentType']

            # Save to DynamoDB
            table = dynamodb.Table(TABLE_NAME)
            table.put_item(Item={
                'fileId': key,
                'bucket': bucket,
                'type': content_type,
                'size': file_size
            })

            print(f"Successfully added metadata for {key}")
        
        except Exception as e:
            print(f"Error processing {key}: {str(e)}")
            raise e

    return {
        'statusCode': 200,
        'body': json.dumps('Metadata saved successfully!')
    }
