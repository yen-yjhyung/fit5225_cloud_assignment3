import boto3
import base64
import os
import json

s3 = boto3.client('s3')
BUCKET_NAME = os.environ['BUCKET_NAME']

def lambda_handler(event, context):
    try:
        print("Received event:", event)
        
        if not event.get("body"):
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({'message': 'Missing request body'})
            }

        body = json.loads(event['body'])
        file = body.get('file')
        file_name = body.get('fileName')

        if not file or not file_name:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({'message': 'Missing file or fileName'})
            }

        header, encoded = file.split(',', 1)
        content_type = header.split(':')[1].split(';')[0]
        decoded = base64.b64decode(encoded)

        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=f"uploads/{file_name}",
            Body=decoded,
            ContentType=content_type
        )

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({'message': 'Upload successful'})
        }

    except Exception as e:
        print("Lambda error:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({'message': f'Internal server error: {str(e)}'})
        }
